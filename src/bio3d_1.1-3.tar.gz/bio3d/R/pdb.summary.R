"pdb.summary" <-
function(pdb) {
  atom.select(pdb)
}

