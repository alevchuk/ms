#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "score.h"

static int getargs(char *line,char *args[],int max);

extern float matrix[NUMRES][NUMRES];

int readmatrix(FILE *fd)
{
   float ResComp[NUMRES][NUMRES];
   char Residues[NUMRES];
   char  c1,c2,last[NUMRES][10];
   int xref[NUMRES];
   int index[NUMRES];
   int i, j, k, ix = 0;
   int found = 0;
   int  maxres, maxcodes;
   float min;
   double f;
   char inline1[1024];
   int  numargs;
   char *args[NUMRES+4];

   while (fgets(inline1,1024,fd) != NULL)
     {
        i = strlen(inline1);
        if (inline1[i-2] == '*')
          {
            found = 1;
/*
   read residue characters.
*/
                 k = 0;
                 for (j=0;j<i-3;j++)
                    if ((inline1[j] >= 'A') && (inline1[j] <= 'Z')) 
                       Residues[k++] = inline1[j];
                 Residues[k] = '\0';
                 maxres = k;
            break;
          }
     }

   if (found == 0) 
     {
        fprintf(stderr,"Error: cannot find residues in matrix\n");
        return 0;
     }

   ix = 0;
   min = 100;
   while (fgets(inline1,1024,fd) != NULL)
     {
        if (inline1[0] == '\n') continue;
        numargs = getargs(inline1, args, maxres+1);
        if (numargs != maxres+1)
          {
             fprintf(stderr,"Error: wrong format in matrix\n");
             return 0;
          }
        for (i=0;i<maxres;i++)
          {
             f = atof(args[i]);
             ResComp[ix][i] = f;
             ResComp[i][ix] = ResComp[ix][i];
	     if (min>f) min = f;
          }
        ix++;
        if (ix==numargs) break;
     }

   if (ix != numargs)
     {
        fprintf(stderr,"Error: wrong lines in matrix\n");
        return 0;
     }

   for (i=0; i<maxres; i++)
	index[i]=Residues[i]-'A';

   for (i=0; i<26; i++)
        for (j=0; j<26; j++)
               matrix[i][j]=0;

   for (i=0; i<maxres; i++)
   	for (j=0; j<maxres; j++)
		matrix[index[i]][index[j]]=ResComp[i][j];

/* make the matrix positive */
/*
   min=matrix[0][0];
   for (i=0; i<26; i++)
        for (j=0; j<26; j++)
               if(min>matrix[i][j]) min=matrix[i][j];

   if(min<0.0)
   for (i=0; i<26; i++)
        for (j=0; j<26; j++)
               matrix[i][j]-=min;
*/
/*

  fprintf(stdout," ");
   for (i=0; i<26; i++)
        fprintf(stdout,"%c  ", i+'A');
   fprintf(stdout,"*\n");

   for (i=0; i<26; i++)
        for (j=0; j<26; j++)
               fprintf(stdout,"%2.0f ", matrix[i][j]);
*/
	return 1;

}

static int getargs(char *line,char *args[],int max)
{
 
        char    *inptr;
        int     i;
 
        inptr=line;
        for (i=0;i<=max;i++)
        {
                if ((args[i]=strtok(inptr," \t\n"))==NULL)
                        break;
                inptr=NULL;
        }
        if (i>max)
        {
                fprintf(stdout,"Too many args\n");
                return(0);
        }
 
        return(i);
}

