#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include "score.h"

void mk_a_group(int seed);

int groups[MAXSEQ][MAXSEQ];
int grouplen[MAXSEQ];
Boolean grouped[MAXSEQ];
int ngroups;
int cutoff=25;
int nalign;
int norphans;


int main(int argc, char **argv)
{

/* calculate the groups */

        for (i=0;i<nseqs;i++) {
                grouped[i]=FALSE;
                for (j=0;j<nseqs;j++) groups[i][j]=0;
        }

        ngroups=0;
        norphans=nseqs;
        seed=0;

        while (norphans>0) {
                mk_a_group(seed);
                norphans=0;
                for (i=0;i<nseqs;i++)
                        if(grouped[i]==FALSE) {
                                if (norphans==0) seed=i;
                                norphans++;
                        }
        }

	norphans=0;
        for(i=0;i<ngroups;i++)
        {
                if(grouplen[i]==1)
                {
                        for(j=0;j<nseqs;j++)
                                if(groups[i][j]==1) norphans++;
                }
        }

void mk_a_group(int seed)
{
        int last_time;
        int i,j,k;
        Boolean found;
        int no;

        groups[ngroups][seed]=1;
        grouplen[ngroups]=1;
        grouped[seed]=TRUE;
        ngroups++;
        norphans--;

        last_time=norphans;
        while(1) {
                no=0;
                for (i=0;i<nseqs;i++)
                {
                        if(grouped[i]==FALSE) {
                                found=FALSE;
                                for(j=0;j<ngroups;j++)
                                {
                                        for(k=0;k<nseqs;k++)
                                                if(groups[j][k]==1 && pcid[i][k]>cutoff)
                                                {
                                                        groups[j][i]=1;
                                                        grouplen[j]++;
                                                        grouped[i]=TRUE;
                                                        found=TRUE;
                                                        break;
                                                }
                                        if(found==TRUE) break;
                                }
                                if(found==FALSE) no++;
                        }
                }
                if(no==last_time) break;
                last_time=no;
        }
}


