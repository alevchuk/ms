#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include "score.h"

void sort_scores(float *scores,int f,int l);
float md_score(float matrix[NUMRES][NUMRES],float **weight,float totweight,Boolean *fragment);
float max_score(int len,Boolean *fragment);
void score_gaps(int s1,int s2);
void *ckfree(void *ptr);
void *ckalloc(size_t bytes);
void *ckrealloc(void *ptr,size_t bytes);
float pcidentity(int i,int j);
int readmsf(FILE *fd);
int countmsf(FILE *fd);

static Boolean blankline(char *line);
static void swap(float *scores,int s1, int s2);
static float normalise_score(float score,float n,float ntot,float ntotseq);
static void mk_a_group(int seed,float cutoff,int *seqgroup,int *grouplen);

extern char **names;
extern char **seq_array;
extern int *seqlen_array;
extern int seqlength;
extern int nseqs;
extern int *useqlen_array;
extern int *use_seq;

extern float **gop;
extern float **gep;


extern int ngroups;
extern int norphans;
extern int **groups;
extern float **pcid;
extern Boolean *fragment;

void score_gaps(int s1,int s2)
{
	int i,j,k,start,len;
	int is,ie;
   	int count, total, ngaps, gaplen;
   	char c1,c2;
	float score;
	char *seq1,*seq2;
	Boolean in_gap,lin_gap;

 
   	if(seqlen_array[s1]<seqlen_array[s2]) len = seqlen_array[s1];
   	else len = seqlen_array[s2];

/* find the start and end of the pairwise alignment */
	is=0;
	ie=seqlength;

	for(k=0;k<len;k++) {
     		c1 = seq_array[s1][k];
     		c2 = seq_array[s2][k];
		if (isalpha(c1) && isalpha(c2)) {
			is=k;
			break;
		}
	}
	for(k=len-1;k>=0;k--) {
     		c1 = seq_array[s1][k];
     		c2 = seq_array[s2][k];
		if (isalpha(c1) && isalpha(c2)) {
			ie=k;
			break;
		}
	}

/* remove common gap positions */
	seq1=(char *)ckalloc((len+1) * sizeof(char));
	seq2=(char *)ckalloc((len+1) * sizeof(char));
	len=0;
	for(i=is;i<ie;i++) {
		if(isalpha(seq_array[s1][i]) || isalpha(seq_array[s2][i])) {
			seq1[len]=seq_array[s1][i];
			seq2[len]=seq_array[s2][i];
			len++;
		}
	}

	ngaps=gaplen=0;
	lin_gap=in_gap=FALSE;
	for(i=0;i<len;i++)
	{
		if(isalpha(seq1[i]))
		{
			in_gap=FALSE;
		}
		else
		{
			if(in_gap==FALSE) ngaps++;
			gaplen++;
			in_gap=TRUE;
		}
		lin_gap=in_gap;
	}
	lin_gap=in_gap=FALSE;
	for(i=0;i<len;i++)
	{
		if(isalpha(seq2[i]))
		{
			in_gap=FALSE;
		}
		else
		{
			if(in_gap==FALSE) ngaps++;
			gaplen++;
			in_gap=TRUE;
		}
		lin_gap=in_gap;
	}

	/*score=ngaps*go + gaplen*ge;*/

	gop[s1][s2]=gop[s2][s1]=ngaps;
	gep[s1][s2]=gep[s2][s1]=gaplen;

	ckfree(seq1);
	ckfree(seq2);
}


/* calculate the maximum possible md score given the number of sequences and the
estimated average similarity */

float max_score(int len,Boolean *fragment)
{
	char c;
	int k,is,ie;
	float sum;
	int s,p;
	float n,*ntot,ntotseq,score;

	n=0;
	for(s=0;s<nseqs;s++)
		if (use_seq[s]>1) n++;
	if(n<2) return 1.0;
		
	ntotseq=0;
	for(s=0;s<nseqs;s++)
		if (use_seq[s]>1) ntotseq++;

/* make ntot the number of sequences at this position, excluding fragments */
	ntot=(float *)ckalloc((seqlength+1)*sizeof(float));
    	for(p=0; p<seqlength; p++) {
		ntot[p]=0;
	}
	for(s=0;s<nseqs;s++)
		if (use_seq[s]>1) {
			if(fragment[s]) 
				len=useqlen_array[s];
			else
				len=seqlength;
        		is=0;
			ie=len-1;
			for(p=is;p<=ie;p++) ntot[p]++;
		}
	sum=0.0;
	for(p=0;p<seqlength;p++)
	{
		n=0;
    		for(s=0; s<nseqs; s++)
			if(use_seq[s]>1)
				if(p<useqlen_array[s]) n++;
		score=normalise_score(1.0,n,ntot[p],ntotseq);
		sum+=score;
	}
	ckfree(ntot);

	return sum;
}

float md_score(float matrix[NUMRES][NUMRES],float **weight,float totweight,Boolean *fragment)
{
	char c;
	int i,j,k,s,s1,p,r;
	int len,is,ie;
	float *ntot,ntotseq;
	float mean,n,score;
	float dist,diff,sum;
	float seqvector[26],seqvector1[26];
	float resdist[26][26];
	float resfreq[26][26];

	ntotseq=0;
	for(s=0;s<nseqs;s++)
		if (use_seq[s]>1) ntotseq++;

	ntot=(float *)ckalloc((seqlength+1)*sizeof(float));
    	for(p=0; p<seqlength; p++) {
		ntot[p]=0;
	}
	
/* make ntot the number of sequences at this position, excluding fragments */
	for(s=0;s<nseqs;s++)
		if (use_seq[s]>1) {
			len=seqlen_array[s];
        		is=0;
			ie=len;
			if(fragment[s]) {
        			for(k=0;k<len;k++) {
                			c = seq_array[s][k];
                			if (isalpha(c)) {
                        			is=k;
                        			break;
                			}
        			}
        			for(k=len-1;k>=0;k--) {
                			c = seq_array[s][k];
                			if (isalpha(c)) {
                        			ie=k;
                        			break;
                			}
        			}
			}
			for(p=is;p<=ie;p++) ntot[p]++;
		}

	for(i=0;i<26;i++) {
                for (r=0;r<26; r++)
                        seqvector[r]=matrix[r][i];
                resdist[i][i]=0.0;
                for(j=i+1;j<26;j++) {
                        for (r=0;r<26; r++)
                                seqvector1[r]=matrix[r][j];
                        resdist[i][j]=0.0;
                        for(r=0;r<26;r++) {
                                diff=seqvector1[r]-seqvector[r];
                                resdist[i][j]+=diff*diff;
                        }
                        resdist[i][j]=sqrt((double)resdist[i][j]);
                        resdist[j][i]=resdist[i][j];
                }
        }
	sum=0.0;
    	for(p=0; p<seqlength; p++)
	{
		if(ntot[p]<1) continue;
    		for(i=0;i<26;i++)
    			for(j=0;j<26;j++)
				resfreq[i][j]=0.0;
/* calculate mean of seq distances */
		mean=0.0;
    		for(s=0; s<nseqs; s++)
		{
			if(use_seq[s]>1)
			if(isalpha(seq_array[s][p])) {
    				for(s1=s+1; s1<nseqs; s1++)
				{
					if(use_seq[s1]>1)
					if(isalpha(seq_array[s1][p])) {
						resfreq[seq_array[s][p]-'A'][seq_array[s1][p]-'A']+=weight[s][s1];
					}
				}
			}
		}
    		for(i=0;i<26;i++) {
    			for(j=0;j<26;j++) {
				mean+=resdist[i][j]*resfreq[i][j];
			}
		}
		/*mean/=(float)(ntot)*(float)(ntot-1)/2.0;*/
		mean/=totweight;

/* normalise score between 0 and 1 (where 1 is an identical column) */

		score=exp((double)(-mean)/(double)2.0);

/* normalise the score for the number of sequences with residues at this position */
		n=0;
    		for(s=0; s<nseqs; s++)
			if(use_seq[s]>1)
			if(isalpha(seq_array[s][p]) )
				n++;
		score=normalise_score(score,n,ntot[p],ntotseq);
/*fprintf(stdout,"%d %f %f %f %f\n",p+1,n,ntot[p],ntotseq,score);*/
		sum+=score;
	}
	ckfree(ntot);
	return sum;
}

static float normalise_score(float score,float n,float ntot,float ntotseq)
{
	float ret;

	if(n==0) ret=0.0;
	else 
		ret=score*exp((double)(-10.0*(float)(ntot-n)/((float)(ntot))));

	return ret;

}


void sort_scores(float *scores,int f,int l)
{
        int i,last;

        if(f>=l) return;

        swap(scores,f,(f+l)/2);
        last=f;
        for(i=f+1;i<=l;i++)
        {
                if(scores[i]>scores[f])
                        swap(scores,++last,i);
        }
        swap(scores,f,last);
        sort_scores(scores,f,last-1);
        sort_scores(scores,last+1,l);

}

static void swap(float *scores,int s1, int s2)
{
        float temp;

        temp=scores[s1];
        scores[s1]=scores[s2];
        scores[s2]=temp;
}

void *ckrealloc(void *ptr, size_t bytes)
{
        register void *ret=NULL;

        if (ptr == NULL) {
                fprintf(stderr,"Bad call to ckrealloc\n");
		exit;
	}
        else if( (ret = realloc(ptr, bytes)) == NULL) {
                fprintf(stderr,"Out of memory\n");
		exit;
	}
        else
                return ret;

        return ret;
}

void *ckalloc(size_t bytes)
{
        register void *ret;

        if( (ret = calloc(bytes, sizeof(char))) == NULL) {
                fprintf(stderr,"Out of memory\n");
                exit;
        }
        else
                return ret;

        return ret;
}
void *ckfree(void *ptr)
{
        if (ptr == NULL)
                fprintf(stderr,"Bad call to ckfree\n");
        else {
                free(ptr);
                ptr = NULL;
        }
        return ptr;
}

float pcidentity(int i,int j)
{
   char c1,c2;
   int k;
   int count, total, len;
   float pcid;

   if(seqlen_array[i]<seqlen_array[j]) len = seqlen_array[i];
   else len = seqlen_array[j];

   count = total = 0;
   for (k=0;k<len;k++) {
     c1 = seq_array[i][k];
     c2 = seq_array[j][k];
     /*if (isalpha((int)c1) && isalpha((int)c2)) {*/
     if (isalpha((int)c1)) {
        total++;
        if (c1 == c2) count++;
     }
   }

   if (total == 0) pcid = 0;
   else pcid = (float)count / (float)len;

   return(pcid);
}

int readmsf(FILE *fin)
{
        char line[MAXLINE+1];
        char *seq=NULL;
        int len,seqno,i,j,k;
        unsigned char c;

for(seqno=0;seqno<nseqs;seqno++)
{

        fseek(fin,0,0);                 /* start at the beginning */

        len=0;                         /* initialise length to zero */
        for(i=0;;i++) {
                if(fgets(line,MAXLINE+1,fin)==NULL) return 1; /* read the title*/
                if(line[0]=='/' && line[1]=='/') break;
 
        }

        while (fgets(line,MAXLINE+1,fin) != NULL) {
                if(!blankline(line)) {

                        for(i=0;i<seqno;i++) fgets(line,MAXLINE+1,fin);
                        for(j=0;j<=strlen(line);j++) if(line[j] != ' ') break;
                        for(k=j;k<=strlen(line);k++) if(line[k] == ' ') break;
                        strncpy(names[seqno],line+j,k-j);
                        names[seqno][k-j]='\0';
                        names[seqno][MAXNAMES]='\0';

			if(seq==NULL)
				seq=(char *)ckalloc((MAXLINE+2)*sizeof(char));
			else
				seq=(char *)ckrealloc(seq,(len+MAXLINE+2)*sizeof(char));

                        for(i=k;i<=MAXLINE;i++) {
                                c=line[i];
                                if(c == '.' || c == '~' ) c = '-';
                                if(c == '*') c = 'X';
                                if(c == '\n' || c == EOS) break; /* EOL */
                                if(isalpha(c) || c=='-') seq[len++]=c;
                        }

                        for(i=0;;i++) {
                                if(fgets(line,MAXLINE+1,fin)==NULL) break;
                                if(blankline(line)) break;
                        }
                }
        }	
	seq[len]='\0';
	seq_array[seqno]=(char *)ckalloc((len+1)*sizeof(char));
	strcpy(seq_array[seqno],seq);
	if(seqno==0) seqlength=len;
	seqlen_array[seqno]=len;
	seq=(void *)ckfree(seq);
}
	return 0;
}

int countmsf(FILE *fin)
{
/* count the number of sequences in a PILEUP alignment file */

        char line[MAXLINE+1];
        int  lnseqs;
	Boolean found;

	found=FALSE;
        while (fgets(line,MAXLINE+1,fin) != NULL) {
                if(line[0]=='/' && line[1]=='/') {
			found=TRUE;
			break;
		}
        }
	if(found==FALSE) {
		return -1;
	}

        while (fgets(line,MAXLINE+1,fin) != NULL) {
                if(!blankline(line)) break;             /* Look for next non- */
        }                                               /* blank line */
        lnseqs = 1;

        while (fgets(line,MAXLINE+1,fin) != NULL) {
                if(blankline(line)) return lnseqs;
                lnseqs++;
        }

        return 0; /* if you got to here-funny format/no seqs.*/
}

static Boolean blankline(char *line)
{
        int i;

/* check for html lines */
	if(line[0]=='<') return TRUE;
        for(i=0;line[i]!='\n' && line[i]!=EOS;i++) {
                if( isdigit(line[i]) ||
                    isspace(line[i]) ||
                    (line[i] == '*') ||
                    (line[i] == ':') ||
                    (line[i] == '.'))
                        ;
                else
                        return FALSE;
        }
        return TRUE;
}


static void mk_a_group(int seed,float cutoff,int *seqgroup,int *grouplen)
{
        int last_time;
        int i,j,k;
        Boolean found;
        int no;

/* the seed sequence becomes the first member of the new group */
        groups[ngroups][seed]=1;
        grouplen[ngroups]=1;
        ngroups++;
        seqgroup[seed]=ngroups;
        norphans--;

        last_time=norphans;
        while(1) {
                no=0;
/* for each sequence that hasn't been grouped yet, check whether it shares high enough percent identity
with a sequence in a group */
                for (i=0;i<nseqs;i++)
                {
                        if(use_seq[i]>1 && seqgroup[i]==0) {
                                found=FALSE;
                                for(j=0;j<ngroups;j++)
                                {
                                        for(k=0;k<nseqs;k++) {
                                                if(use_seq[k]>1 && groups[j][k]==1 && (pcid[i][k])>cutoff)
                                                {
                                                        groups[j][i]=1;
                                                        grouplen[j]++;
                                                        seqgroup[i]=ngroups;
                                                        found=TRUE;
                                                        break;
                                                }
					}
                                        if(found==TRUE) break;
                                }
                                if(found==FALSE) no++;
                        }
                }
                if(no==last_time) break;
                last_time=no;
        }
}

void calc_groups(int seed,float cutoff)
{
	int i,j;
	int *grouplen;
	int *seqgroup;

	grouplen=(int *)ckalloc((nseqs+1)*sizeof(int));
	seqgroup=(int *)ckalloc((nseqs+1)*sizeof(int));

        for (i=0;i<nseqs;i++) {
                seqgroup[i]=0;
                for (j=0;j<nseqs;j++) groups[i][j]=0;
        }

        ngroups=0;
        norphans=nseqs;

        while (norphans>0) {
                mk_a_group(seed,cutoff,seqgroup,grouplen);
                norphans=0;
                for (i=0;i<nseqs;i++)
                        if(use_seq[i]>1 && seqgroup[i]==0) {
                                if (norphans==0) seed=i;
                                norphans++;
                        }
        }

        norphans=0;
        for(i=0;i<ngroups;i++)
        {
                if(grouplen[i]==1)
                {
                        for(j=0;j<nseqs;j++)
                                if(groups[i][j]==1) norphans++;
                }
        }

	ckfree(grouplen);
	ckfree(seqgroup);
}

