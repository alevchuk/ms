/* NORMD version 1.1 feb 2002 */
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include "score.h"

#define MIN(a,b) ((a)<(b)?(a):(b))
#define GCG_LINELENGTH 50


extern int readmatrix(FILE *ifd);
extern void seq_dist(char *seqname, int nseqs);
extern int read_tree(char *treefile, int nseqs);
extern void clear_tree(treeptr p);
extern int readmsf(FILE *fd);
extern int countmsf(FILE *fd);
extern float pcidentity(int i,int j);
extern float md_score(float matrix[NUMRES][NUMRES],float **weight,float totweight,Boolean *fragment);
extern float max_score(int len,Boolean *fragment);
extern void score_gaps(int s1,int s2);
extern float countid(char *seq1,char *seq2,int length);
extern void calc_groups(int seed,float cutoff);

void calc_md(void);
void remove_gaps(void);
void gcg_out(FILE *ofd);
int SeqGCGCheckSum(char *seq, int len);
float set_mdcutoff(int ntot,float md_cutoff);

int *use_seq;
char **names;
char **seq_array;
int *seqlen_array;
int seqlength;
int nseqs;
int *useqlen_array;
int useqlength;
Boolean *fragment;

float matrix[NUMRES][NUMRES];
float go;
float ge;

double **tmat;

float **seqweight;

float gap_openscore,gap_extscore;
float **gop;
float **gep;
float *seq_score;

float norm_md,col;
float max_colscore;
int query;

int **groups;
int *seqgroup;
int ngroups;
int norphans;

float **pcid;

int main(int argc, char **argv)
{
	FILE *ofd,*ifd,*tfd,*treefd;
	int  i,j,l,n,ires;
	int err,ix,ntot;
	char aln_file[MAXLINE+1];
	char query_name[MAXLINE+1];
	char tmpquery_name[MAXLINE+1];
	char tree_file[MAXLINE+1];
	char outname[MAXLINE+1];
	char tmpstr[MAXLINE+1];
	Boolean eof,found;
        int iseq;
	int querylen;
        float minid,tmp;
	float md_cutoff,meanweight;

        if(argc!=7 && argc!=8) {
                fprintf(stdout,"%s Version 1.1\n",argv[0]);
                fprintf(stdout,"Usage: %s aln_file matrix gop gep cutoff output_file [query]\n",argv[0]);
                exit(1);
        }

/* open the test aln file */

	strcpy(aln_file,argv[1]);
        if((tfd=fopen(aln_file,"r"))==NULL) {
            fprintf(stdout,"Error: Cannot open test aln file [%s]\n",aln_file);
            exit(1);
        }

/* open the matrix file */

        if((ifd=fopen(argv[2],"r"))==NULL) {
            fprintf(stdout,"Error: Cannot open matrix file [%s]",argv[2]);
            exit(1);
        }

	go=atof(argv[3]);
	ge=atof(argv[4]);
	md_cutoff=atof(argv[5]);
	if(md_cutoff<=0 || md_cutoff>100) {
            fprintf(stdout,"Error: Bad cutoff specified (value should be between 0 and 100)\n");
            exit(1);
	}


	strcpy(outname,argv[6]);

/* read the test aln into names, seq_array, seqlength */
        nseqs = countmsf(tfd);
        if(nseqs<0) {
                fprintf(stdout,"Error: bad format in alignment file. ");
                fprintf(stdout,"Alignment should be in GCG's MSF format.\n");
                return 0;
	}
        if(nseqs==0) {
                fprintf(stdout,"Error: no sequences in alignment file. ");
                fprintf(stdout,"Alignment should be in GCG's MSF format.\n");
                return 0;
        }
	names=(char **)ckalloc((nseqs+1)*sizeof(char *));
        seq_array=(char **)ckalloc((nseqs+1)*sizeof(char *));
        seqlen_array=(int *)ckalloc((nseqs+1)*sizeof(int));
        for(i=0;i<nseqs;i++) {
                names[i]=(char *)ckalloc((MAXNAMES+1)*sizeof(char));
        }

        err=readmsf(tfd);
	if(err>0) {
                fprintf(stdout,"Warning: alignment too long\n");
		return 0;
	}

        if((ofd=fopen(outname,"w"))==NULL) {
            fprintf(stdout,"Cannot open output file [%s]",outname);
            return 0;
        }

	if(argc==8)
		strcpy(query_name,argv[7]);
	else
		strcpy(query_name,names[0]);
	strcat(tree_file,aln_file);
	strcat(tree_file,".ph");

/* find the query sequence */
	query=-1;
	for(j=0;j<strlen(query_name);j++)
		if (isalpha(query_name[j])) tmpquery_name[j]=tolower(query_name[j]);
		else tmpquery_name[j]=query_name[j];
	tmpquery_name[j]='\0';
	for(i=0;i<nseqs;i++) {
		for(j=0;j<strlen(names[i]);j++)
			if (isalpha(names[i][j])) tmpstr[j]=tolower(names[i][j]);
			else tmpstr[j]=names[i][j];
		tmpstr[j]='\0';
		if(strcmp(tmpquery_name,tmpstr)==0) query=i;
	}
	if(query==-1) {
                fprintf(stdout,"Error: the specified reference sequence (%s) was not found in the alignment\n",query_name);
                exit(1);
	}

	for(i=0;i<nseqs;i++)
		for(j=0;j<seqlen_array[i];j++)
			if(isalpha(seq_array[i][j]))
				seq_array[i][j]=toupper(seq_array[i][j]);

/* remove the gaps */
        useqlen_array=(int *)ckalloc((nseqs+1)*sizeof(int));
	useqlength=0;
	for(i=0;i<nseqs;i++) {
		l=0;
		for(j=0;j<seqlen_array[i];j++)
			if(isalpha(seq_array[i][j])) {
				l++;
			}
		useqlen_array[i]=l;
		if (l>useqlength) useqlength=l;
	}
	querylen=useqlen_array[query];

	err=readmatrix(ifd);
	if(err<=0) {
		fprintf(stdout,"Error: bad matrix in %s\n",argv[3]);
		exit(1);
	}
	
/* calculate some simple statistics */
        pcid=(float **)ckalloc((nseqs+1)*sizeof(double *));
        for(i=0;i<=nseqs;i++)
                pcid[i]=(float *)ckalloc((nseqs+1)*sizeof(double));
        tmat=(double **)ckalloc((nseqs+2)*sizeof(double *));
        for(i=0;i<=nseqs;i++)
                tmat[i]=(double *)ckalloc((nseqs+2)*sizeof(double));
        for(i=0;i<nseqs;i++) {
		pcid[i][i]=1.0;
		tmat[i+1][i+1]=0.0;
		for(j=i+1;j<nseqs;j++) {
			pcid[j][i]=pcid[i][j]=pcidentity(i,j);
			tmat[i+1][j+1]=1.0-pcid[i][j];
			tmat[j+1][i+1]=tmat[i+1][j+1];
		}
	}

	seqweight=(float **)ckalloc((nseqs+1)*sizeof(float *));
	for(i=0;i<nseqs;i++)
		seqweight[i]=(float *)ckalloc((nseqs+1)*sizeof(float));
        for(i=0;i<nseqs;i++) 
		for(j=i;j<nseqs;j++) {
			seqweight[j][i]=seqweight[i][j]=tmat[i+1][j+1];
		}

/* write the tree file */
        if((treefd=fopen(tree_file,"w"))==NULL) {
            fprintf(stdout,"\nError: Cannot write tree file [%s]",tree_file);
            exit(1);
        }
        guide_tree(treefd,nseqs);

        err=read_tree(tree_file,nseqs);
        if(err<=0) {
                fprintf(stdout,"\nError: wrong format in tree file %s\n",tree_file);
                exit(1);
        }

	seq_score=(float *)ckalloc((nseqs+1)*sizeof(float));
        seq_dist(query_name,nseqs);

        seq_score[query]=1.0;

        clear_tree(NULL);
	strcpy(tmpstr,"rm ");
	strcat(tmpstr,tree_file);
/*	system(tmpstr);*/

/* calculate the scores for the gaps */
        gop=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                gop[i]=(float *)ckalloc((nseqs+1)*sizeof(float));
        gep=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                gep[i]=(float *)ckalloc((nseqs+1)*sizeof(float));

       	for(i=0,n=0;i<nseqs;i++) 
              	for(j=i+1;j<nseqs;j++)
			score_gaps(i,j);

	fragment=(Boolean *)ckalloc((nseqs+1)*sizeof(Boolean));

	use_seq=(int *)ckalloc((nseqs+1)*sizeof(int));
	for(i=0;i<nseqs;i++)
		use_seq[i]=2;

        seqgroup=(int *)ckalloc((nseqs+1)*sizeof(int));
        groups=(int **)ckalloc((nseqs+1)*sizeof(int *));
	for(i=0;i<nseqs;i++)
		groups[i]=(int *)ckalloc((nseqs+1)*sizeof(int));
	calc_groups(query,0.5);
	for(i=0;i<ngroups;i++) {
		for(j=0;j<nseqs;j++)
			if(groups[i][j]==1) seqgroup[j]=i;
	}

	for(i=0;i<ngroups;i++) {
		found=FALSE;
		for(j=0;j<nseqs;j++) {
			if(use_seq[j]>1 && groups[i][j]==1) {
				if(!found) {
					found=TRUE;
				}
				else use_seq[j]=(-1);
			}
		}
	}

	calc_md();
	for(i=0,ntot=0;i<nseqs;i++) 
		if(use_seq[i]>1) ntot++;
	tmp=set_mdcutoff(ntot,md_cutoff);
	norm_md/=tmp;

        fprintf(stdout,"norMD Score - original		%.3f\n\n",norm_md);
        fprintf(stdout,"The following parameters were used in the normalisation:\n");
        fprintf(stdout,"Number of sequences		%d\n",nseqs);
        fprintf(stdout,"MD Score			%.3f\n",col);
        fprintf(stdout,"maximum MD			%.3f\n",max_colscore);
        fprintf(stdout,"Gap Opening Penalty		%.3f\n",gap_openscore);
        fprintf(stdout,"Gap Extension Penalty		%.3f\n",gap_extscore);
        /*fprintf(stdout,"Scale %.3f\n",tmp);*/


	fprintf(stdout,"\n");

	if(norm_md>md_cutoff) {
		fprintf(stdout,"The norMD score is above the cutoff [%.3f]:\n\n",md_cutoff);
		fprintf(stdout,"Alignment OK - removing no sequences\n");
		for(i=0;i<nseqs;i++) 
			use_seq[i]=2;
	}
	else {

	fprintf(stdout,"The norMD score is below the cutoff [%.3f]:\n\n",md_cutoff);
	fprintf(stdout,"Check for sequences unrelated to reference sequence %s:\n\n",query_name);
	while(1) {
		n=0;
		for(i=0;i<nseqs;i++) 
			if(use_seq[i]>1) 
				n++;
		if(n<2) break;

/* find the sequence with the lowest similarity with the query */
		minid=1.0;
		for(i=0;i<nseqs;i++) {
			if(i!=query && seqgroup[i]!=seqgroup[query] && use_seq[i]>1 && seq_score[i]<minid) {
				minid=seq_score[i];	
				iseq=i;
			}
		}
		if(minid==1.0) break;
		use_seq[iseq]=0;
		calc_md();
		for(i=0,ntot=0;i<nseqs;i++) 
			if(use_seq[i]>1) ntot++;
		tmp=set_mdcutoff(ntot,md_cutoff);
		norm_md/=tmp;
/*
        fprintf(stdout,"Removing: %s\n",names[iseq]);
        fprintf(stdout,"norMD %.3f\n",norm_md);
        fprintf(stdout,"NSEQS %d\n",ntot);
        fprintf(stdout,"MD    %.3f\n",col);
        fprintf(stdout,"maxMD %.3f\n",max_colscore);
        fprintf(stdout,"GOP   %.3f\n",gap_openscore);
        fprintf(stdout,"GEP   %.3f\n",gap_extscore);
        fprintf(stdout,"Scale %.3f\n",tmp);
*/
		if(norm_md>md_cutoff) break;
	}

	/*for(i=0;i<nseqs;i++) 
                if(use_seq[i]>0) fprintf(stdout,"Core sequence: %s\n",names[i]);*/
/* now try each rejected sequence by itself */


	for(i=0;i<nseqs;i++) 
                if(use_seq[i]>0) use_seq[i]=2;

	ntot++;
	for(i=0;i<nseqs;i++)  {
		if(use_seq[i]==0) {
			use_seq[i]=2;
			calc_md();
			tmp=set_mdcutoff(ntot,md_cutoff);
			norm_md/=tmp;
/*
        fprintf(stdout,"Trying: %s\n",names[i]);
        fprintf(stdout,"norMD %.3f\n",norm_md);
        fprintf(stdout,"NSEQS %d\n",ntot);
        fprintf(stdout,"MD    %.3f\n",col);
        fprintf(stdout,"maxMD %.3f\n",max_colscore);
        fprintf(stdout,"GOP   %.3f\n",gap_openscore);
        fprintf(stdout,"GEP   %.3f\n",gap_extscore);
        fprintf(stdout,"Scale %.3f\n",tmp);
*/
			if(norm_md>md_cutoff) {
				use_seq[i]=1;
			}
			else {
				use_seq[i]=0;
			}
		}
	}

	remove(tree_file);
	calc_md();
	for(i=0,ntot=0;i<nseqs;i++) 
		if(use_seq[i]>1) ntot++;
	tmp=set_mdcutoff(ntot,md_cutoff);
	norm_md/=tmp;

	for(i=0;i<nseqs;i++) {
                if(use_seq[i]>1) {
			for(j=0;j<nseqs;j++)
				if(i!=j && groups[seqgroup[i]][j]==1) {
					use_seq[j]=use_seq[i];
				}
		}
                if(use_seq[i]==0) {
			fprintf(stdout,"Remove: %s\n",names[i]);
/* also remove all sequences in the same group */
			for(j=0;j<nseqs;j++)
				if(i!=j && groups[seqgroup[i]][j]==1) {
					fprintf(stdout,"Remove: %s\n",names[j]);
				}
		}
	}

	for(i=0,ntot=0;i<nseqs;i++) 
		if(use_seq[i]>1) ntot++;
	fprintf(stdout,"\n");

        fprintf(stdout,"FINAL ALIGNMENT (after removal of bad sequences): \n");
        fprintf(stdout,"norMD Score - final		%.3f\n\n",norm_md);
        fprintf(stdout,"The following parameters were used in the normalisation:\n");
        fprintf(stdout,"Number of sequences		%d\n",ntot);
        fprintf(stdout,"MD Score			%.3f\n",col);
        fprintf(stdout,"maximum MD			%.3f\n",max_colscore);
        fprintf(stdout,"Gap Opening Penalty		%.3f\n",gap_openscore);
        fprintf(stdout,"Gap Extension Penalty		%.3f\n",gap_extscore);
        /*fprintf(stdout,"Scale %.3f\n",tmp);*/
	}
	remove_gaps();
	gcg_out(ofd);
	fclose(ofd);

        for(i=0;i<nseqs;i++)
                ckfree(gop);
        ckfree(gop);
        for(i=0;i<nseqs;i++)
                ckfree(gep);
        ckfree(gep);
        for(i=0;i<=nseqs;i++)
                ckfree(tmat);
        ckfree(tmat);
	for(i=0;i<nseqs;i++)
		ckfree(seqweight[i]);
	ckfree(seqweight);
	ckfree(seq_score);
	ckfree(use_seq);
	ckfree(fragment);
}

float set_mdcutoff(int ntot,float md_cutoff)
{
	float n,tmp;
/*
	if(ntot<=2) tmp=22.0;
	else if(ntot<=3) tmp=14.0;
	else if(ntot<=5) tmp=10.0;
	else if(ntot<=6) tmp=9.0;
	else if(ntot<=7) tmp=7.0;
	else if(ntot<=8) tmp=5.0;
	else if(ntot<=9) tmp=4.5;
	else if(ntot<=10) tmp=4.5;
	else if(ntot<=11) tmp=3.5;
	else if(ntot<=13) tmp=3.0;
	else if(ntot<=16) tmp=2.5;
	else if(ntot<=19) tmp=1.9;
	else if(ntot<=20) tmp=1.8;
	else if(ntot<=28) tmp=1.5;
	else tmp=1.4;
*/
	if(ntot>15) n=15;
	else n=ntot;
	tmp=(300.0)/((n*n)*4.0+100.0);
	return tmp;
}
void calc_md(void)
{
	int i,j,n,n1,ntot;
	int maxlen;
	float id;
	float totweight;
	float **weight;

	ntot=0;
        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>1) ntot++;
	/*if(ntot==1) {
		norm_md=100.0;
		return;
	}*/

	weight=(float **)ckalloc((nseqs+1)*sizeof(float *));
	for(i=0;i<nseqs;i++)
		weight[i]=(float *)ckalloc((nseqs+1)*sizeof(float));

	totweight=0;
        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>1) 
		for(j=i+1;j<nseqs;j++) 
			if(use_seq[j]>1) 
				totweight+=seqweight[i][j];


	if (totweight==0) {
        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>1)
		for(j=i+1;j<nseqs;j++) 
			if(use_seq[j]>1)
				totweight++;
	}
	if(totweight<1) totweight=1;

        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>1)
		for(j=i+1;j<nseqs;j++) 
			if(use_seq[j]>1) {
			weight[j][i]=weight[i][j]=seqweight[i][j];
			}

	gap_openscore=0.0;
	gap_extscore=0.0;
       	for(i=0,n=0;i<nseqs;i++) 
		if(use_seq[i]>1) {
              		for(j=i+1;j<nseqs;j++) {
				if(use_seq[j]>1) {
				gap_openscore+=gop[i][j]*weight[i][j];
				gap_extscore+=gep[i][j]*weight[i][j];
				n++;
				}
			}
		}
	gap_openscore/=totweight;
	gap_extscore/=totweight;


/* calculate mean column score */
	maxlen=0;
        for(i=0;i<nseqs;i++) 
                if(useqlen_array[i]>maxlen) maxlen=useqlen_array[i];
	
	max_colscore=max_score(maxlen,fragment);
	col=md_score(matrix,weight,totweight,fragment);

        if(max_colscore>0) norm_md=100.0*(col-gap_openscore*go-gap_extscore*ge)/(max_colscore);
       	else norm_md=0.0;

	for(i=0;i<nseqs;i++)
		ckfree(weight[i]);
	ckfree(weight);

}

int sim_score(int i,int j)
{
   char c1,c2;
   int k;
   int total, len;
   int pcsim;
   float count;
 
   if(seqlen_array[i]<seqlen_array[j]) len = seqlen_array[i];
   else len = seqlen_array[j];

   count = total = 0;
   for (k=0;k<len;k++) {
     c1 = tolower(seq_array[i][k]);
     c2 = tolower(seq_array[j][k]);
     if (isalpha((int)c1) && isalpha((int)c2)) {
        total++;
        count+=matrix[c1-'a'][c2-'a'];
     }
   }
 
   if (len == 0) pcsim = 0;
   else pcsim = (100.0 * count) / (float)len;

   return(pcsim);
}

void gcg_out(FILE *ofd)
{
        char *seq, residue;
        int val;
        int *all_checks;
        int i,ii,chunks,block;
        int j,k,pos1,pos2;
        long grand_checksum;

        seq = (char *)calloc((seqlength+1) , sizeof(char));
        all_checks = (int *)calloc((nseqs+1) , sizeof(int));

        for(i=0; i<nseqs; i++) {
		if(use_seq[i]>0) {
                	for(j=0; j<seqlength; j++) {
                        	if(seq_array[i][j]=='\0') break;
                        	if(isalpha(seq_array[i][j]))
                                	seq[j] = seq_array[i][j];
                        	else seq[j]='.';
                	}
/* pad any short sequences with gaps, to make all sequences the same length */
                	for(; j<seqlength; j++)
                        	seq[j] = '.';
                	all_checks[i] = SeqGCGCheckSum(seq, (int)seqlength);
		}
        }

        grand_checksum = 0;
        for(i=0; i<nseqs; i++) if (use_seq[i]>0) grand_checksum += all_checks[i];
        grand_checksum = grand_checksum % 10000;
        fprintf(ofd,"PileUp\n\n");
        fprintf(ofd,"\n\n   MSF:%5d  Type: ",(int)seqlength);
        fprintf(ofd,"P");
        fprintf(ofd,"    Check:%6ld   .. \n\n", (long)grand_checksum);
        for(i=0; i<nseqs; i++)  {
		if(use_seq[i]>0) 
                fprintf(ofd,
                        " Name: %s oo  Len:%5d  Check:%6ld  Weight:  1.00\n",
                        names[i],(int)seqlength,(long)all_checks[i]);
        }
        fprintf(ofd,"\n//\n");

        chunks = seqlength/GCG_LINELENGTH;
        if(seqlength % GCG_LINELENGTH != 0) ++chunks;

        for(block=1; block<=chunks; block++) {
                fprintf(ofd,"\n\n");
                pos1 = ((block-1) * GCG_LINELENGTH) + 1;
                pos2 = (seqlength<pos1+GCG_LINELENGTH-1)? seqlength : pos1+GCG_LINELENGTH-1;
                for(i=0; i<nseqs; i++) {
			if(use_seq[i]>0)  {
                        fprintf(ofd,"\n%-15s ",names[i]);
                        for(j=pos1, k=1; j<=pos2; j++, k++) {
                                if (isalpha(seq_array[i][j-1]))
                                        residue=seq_array[i][j-1];
                                else residue='.';
                                fprintf(ofd,"%c",residue);
                                if(j % 10 == 0) fprintf(ofd," ");
                        }
			}
                }
        }

        free((void *)seq);
        free((void *)all_checks);

        fprintf(ofd,"\n\n");
}


int SeqGCGCheckSum(char *seq, int len)
{
        int  i;
        long check;

        for( i=0, check=0; i< len; i++,seq++)
                check += ((i % 57)+1) * toupper(*seq);

        return(check % 10000);
}

void remove_gaps(void)
{
        int sl;    
        int i,j,n,ns;

	ns=0;
        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>0) ns++;
	
        sl=0;
        for(j=0;j<seqlength;j++) {
		n=0;
        	for(i=0;i<nseqs;i++) 
                        if(use_seq[i]>0 && !isalpha(seq_array[i][j])) n++;
		if(n==ns) continue;
        	for(i=0;i<nseqs;i++) 
                        seq_array[i][sl]=seq_array[i][j];
                sl++;
        }
        for(i=0;i<nseqs;i++) 
                seqlen_array[i]=sl;
	seqlength=sl;
}

