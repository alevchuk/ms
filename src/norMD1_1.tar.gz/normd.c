/* NORMD version 1.1 Feb 2002 */

#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include "score.h"

extern int readmatrix(FILE *ifd);
extern float show_pair(int i,int j);
extern int readmsf(FILE *fd);
extern int countmsf(FILE *fd);
extern float pcidentity(int i,int j);
extern float md_score(float matrix[NUMRES][NUMRES], float **weight, float totweight,Boolean *fragment);
extern float max_score(int len,Boolean *fragment);
extern void score_gaps(int s1,int s2);
extern float countid(char *seq1,char *seq2,int len);
extern void calc_groups(int seed,float cutoff);
extern void mk_a_group(int seed,float cutoff);

void calc_md(void);
float set_mdcutoff(int ntot);

int *use_seq;
char **names;
char **seq_array;
int *seqlen_array;
int seqlength;
int nseqs;
int *useqlen_array;
int useqlength;
Boolean *fragment;

Boolean verbose=FALSE;

float matrix[NUMRES][NUMRES];
float go;
float ge;

double **tmat;

float **seqweight;
float totweight;

float gap_openscore,gap_extscore;
float **gop;
float **gep;

float norm_md,col;
float max_colscore;
int query;

float tl,q1,q3;
float medianqpw;
float *qpw;
float **qpw_id;

int **groups;
int ngroups;
int norphans;

float **pcid;


void usage(char *prog) 
{
	fprintf(stderr,"%s Version 1.1\n",prog);
	fprintf(stderr,"Usage: %s aln_file matrix gop gep [-v]     | calculate norMD for alignment (-v verbose)\n",prog);
}

int main(int argc, char **argv)
{
	FILE *ofd,*ifd,*tfd;
	int  i,j,l,n,ires;
	int err,ix,ntot;
	float tmp;
	Boolean eof,found;

	if(argc!=5 && argc!=6) {
		usage(argv[0]);
		return 0;
	}

	verbose=FALSE;
	if(argc==6) verbose=TRUE;
	
/* open the test aln file */

        if((tfd=fopen(argv[1],"r"))==NULL) {
            fprintf(stderr,"Cannot open test aln file [%s]\n",argv[1]);
            return 0;
        }

/* open the matrix file */

        if((ifd=fopen(argv[2],"r"))==NULL) {
            fprintf(stderr,"Cannot open matrix file [%s]",argv[2]);
            return 0;
        }

	go=atof(argv[3]);
	ge=atof(argv[4]);

/* read the test aln into names, seq_array, seqlength */
        nseqs = countmsf(tfd);
        if(nseqs<=0) {
                /*fprintf(stderr,"Error: no sequences in %s\n",argv[1]);*/
                return 0;
        }
	names=(char **)ckalloc((nseqs+1)*sizeof(char *));
	seq_array=(char **)ckalloc((nseqs+1)*sizeof(char *));
	seqlen_array=(int *)ckalloc((nseqs+1)*sizeof(int));
	for(i=0;i<nseqs;i++) {
		names[i]=(char *)ckalloc((MAXNAMES+1)*sizeof(char));
	}
        err=readmsf(tfd);
	if(err>0) {
                fprintf(stdout,"Warning: alignment too long\n");
		return 0;
	}

	for(i=0;i<nseqs;i++)
		for(j=0;j<seqlen_array[i];j++)
			if(isalpha(seq_array[i][j]))
				seq_array[i][j]=toupper(seq_array[i][j]);

/* remove the gaps */
	useqlen_array=(int *)ckalloc((nseqs+1)*sizeof(int));
	useqlength=0;
	for(i=0;i<nseqs;i++) {
		l=0;
		for(j=0;j<seqlen_array[i];j++)
			if(isalpha(seq_array[i][j])) {
				l++;
			}
		useqlen_array[i]=l;
		if (l>useqlength) useqlength=l;
	}

	err=readmatrix(ifd);
	if(err<=0) {
		fprintf(stderr,"Error: bad matrix in %s\n",argv[3]);
		return 0;
	}
	
/* calculate some simple statistics */
        tmat=(double **)ckalloc((nseqs+2)*sizeof(double *));
        for(i=0;i<=nseqs;i++)
                tmat[i]=(double *)ckalloc((nseqs+2)*sizeof(double));
        pcid=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                pcid[i]=(float *)ckalloc((nseqs+1)*sizeof(float));
        for(i=0;i<nseqs;i++) {
		tmat[i+1][i+1]=0.0;
		for(j=i+1;j<nseqs;j++) {
			pcid[j][i]=pcid[i][j]=pcidentity(i,j);
			tmat[i+1][j+1]=1.0-pcid[i][j];
			tmat[j+1][i+1]=tmat[i+1][j+1];
		}
	}

        seqweight=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                seqweight[i]=(float *)ckalloc((nseqs+1)*sizeof(float));
        for(i=0;i<nseqs;i++) 
		for(j=i;j<nseqs;j++) {
			seqweight[j][i]=seqweight[i][j]=tmat[i+1][j+1];
		}

/* calculate the scores for the gaps */
        gop=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                gop[i]=(float *)ckalloc((nseqs+1)*sizeof(float));
        gep=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                gep[i]=(float *)ckalloc((nseqs+1)*sizeof(float));

       	for(i=0,n=0;i<nseqs;i++) 
              	for(j=i+1;j<nseqs;j++)
			score_gaps(i,j);

	fragment=(Boolean *)ckalloc((nseqs+1)*sizeof(Boolean));

/* calculate pairwise alignment scores using k-tuple scores */
        qpw_id=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                qpw_id[i]=(float *)ckalloc((nseqs+1)*sizeof(float));
        for(i=0,n=0;i<nseqs;i++)
                for(j=i+1;j<nseqs;j++) {
                        qpw_id[i][j]=show_pair(i,j);
			/*qpw_id[i][j]=countid(seq_array[i],seq_array[j],seqlength);*/
			if(qpw_id[i][j]>60) {
				tmp=(float)useqlen_array[i]/(float)useqlen_array[j];
/*fprintf(stdout,"%s %s %f %d %d %f\n",names[i],names[j],qpw_id[i][j],useqlen_array[i],useqlen_array[j],tmp);*/
				if(tmp<0.8) fragment[i]=TRUE;
				else if(tmp>1.25) fragment[j]=TRUE;
			}
			n++;
		}
	if(verbose)
        for(i=0;i<nseqs;i++)
		if(fragment[i]) fprintf(stdout,"fragment %s\n",names[i]);

        use_seq=(int *)ckalloc((nseqs+1)*sizeof(int));
	for(i=0;i<nseqs;i++)
		use_seq[i]=2;

        groups=(int **)ckalloc((nseqs+1)*sizeof(int *));
        for(i=0;i<nseqs;i++)
                groups[i]=(int *)ckalloc((nseqs+1)*sizeof(int));
	query=0;
        calc_groups(query,0.5);

        for(i=0;i<ngroups;i++) {
                found=FALSE;
                for(j=0;j<nseqs;j++) {
                        if(use_seq[j]>1 && groups[i][j]==1) {
                                if(!found) {
                                        found=TRUE;
                                }
                                else use_seq[j]=(-1);
                        }
                }
        }


	qpw=(float *)ckalloc((nseqs*nseqs+1)*sizeof(float));
        for(i=0,n=0;i<nseqs;i++)
		if(use_seq[i]>1)
                for(j=i+1;j<nseqs;j++)
			if(use_seq[j]>1)
                        qpw[n++]=qpw_id[i][j];

/* sort the pairwise k-tuple scores into ascending order */
        sort_scores(qpw,0,n-1);

	calc_md();
	for(i=0,ntot=0;i<nseqs;i++)
		if(use_seq[i]>1) ntot++;
	tmp=set_mdcutoff(ntot);
	norm_md/=tmp;

	if(!verbose) {
        	/*fprintf(stdout,"%s\t%.3f\n",argv[1],norm_md);*/
        	fprintf(stdout,"%.3f\n",norm_md);
	} else {
		/*fprintf(stdout,"FILE  %s\n",argv[1]);*/
        	fprintf(stdout,"norMD %.3f\n",norm_md);
        	fprintf(stdout,"NSEQS %d\n",nseqs);
        	fprintf(stdout,"MD    %.3f\n",col);
        	fprintf(stdout,"maxMD %.3f\n",max_colscore);
        	fprintf(stdout,"GOP   %.3f\n",gap_openscore);
        	fprintf(stdout,"GEP   %.3f\n",gap_extscore);
        	fprintf(stdout,"LQR   %.3f\n",q1);
		fprintf(stdout,"Scale %.3f\n",tmp);
	}

        for(i=0;i<ngroups;i++)
                ckfree(groups);
        ckfree(groups);
        for(i=0;i<nseqs;i++)
                ckfree(gop);
        ckfree(gop);
        for(i=0;i<nseqs;i++)
                ckfree(gep);
        ckfree(gep);
        for(i=0;i<=nseqs;i++)
                ckfree(tmat);
        ckfree(tmat);
        for(i=0;i<nseqs;i++)
                ckfree(pcid);
        ckfree(pcid);
        for(i=0;i<nseqs;i++)
                ckfree(seqweight[i]);
        ckfree(seqweight);
	ckfree(qpw);
	ckfree(use_seq);
	ckfree(fragment);

}

float set_mdcutoff(int ntot)
{
        float n,tmp;

        if(ntot>15) n=15;
        else n=ntot;
        tmp=(300.0)/((n*n)*4.0+100.0);
        return tmp;
}


void calc_md(void)
{
	int i,j,n,ntot;
	int maxlen;
	float **weight;

	ntot=0;
        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>1) ntot++;
	if(ntot==1) {
		norm_md=1.0;
		return;
	}

        weight=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                weight[i]=(float *)ckalloc((nseqs+1)*sizeof(float));


	totweight=0;
        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>1) 
		for(j=i+1;j<nseqs;j++) 
			if(use_seq[j]>1) 
				totweight+=seqweight[i][j];

	if (totweight==0) {
        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>1)
		for(j=i+1;j<nseqs;j++) 
			if(use_seq[j]>1)
				totweight++;
	}

        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>1)
		for(j=i+1;j<nseqs;j++) 
			if(use_seq[j]>1) {
			weight[j][i]=weight[i][j]=seqweight[i][j];
			}

	gap_openscore=0.0;
	gap_extscore=0.0;
       	for(i=0,n=0;i<nseqs;i++) 
		if(use_seq[i]>1) {
              		for(j=i+1;j<nseqs;j++) {
				if(use_seq[j]>1) {
				gap_openscore+=gop[i][j]*weight[i][j];
				gap_extscore+=gep[i][j]*weight[i][j];
				n++;
				}
			}
		}
	gap_openscore/=(float)totweight;
        gap_extscore/=(float)totweight;

/* calculate pairwise alignment scores using k-tuple scores */
        for(i=0,n=0;i<nseqs;i++)
		if(use_seq[i]>1)
                	for(j=i+1;j<nseqs;j++) 
                        	if(use_seq[j]>1) 
                        		n++;


/* find the lower quartile range of the pairwise k-tuple scores */
        if(n == 0)
                medianqpw = 0;
        else if(n % 2 == 0)
                medianqpw=(qpw[n/2-1]+qpw[n/2])/2.0;
        else
                medianqpw=qpw[n/2];

        if(n==0)
                q1=0;
        else {
                tl = (float)n/4.0 + 0.5;
                if(tl - (int)tl == 0.5) {
                        q3=(qpw[(int)tl]+qpw[(int)tl+1])/2.0;
                        q1=(qpw[n-(int)tl]+qpw[n-(int)tl-1])/2.0;
                }
                else if(tl - (int)tl > 0.5) {
                        q3=qpw[(int)tl+1];
                        q1=qpw[n-(int)tl-1];
                }
                else {
                        q3=qpw[(int)tl];
                        q1=qpw[n-(int)tl];
                }
        }
	q1=(1.14*q1-6.4)/100.0;

/* calculate mean column score */
        maxlen=0;
        for(i=0;i<nseqs;i++)
                if(useqlen_array[i]>maxlen) maxlen=useqlen_array[i];

	max_colscore=max_score(maxlen, fragment);
	col=md_score(matrix, weight, totweight, fragment);

       	if(max_colscore>0) norm_md=(col-gap_openscore*go-gap_extscore*ge)/(max_colscore*q1);
       	else norm_md=0.0;

        for(i=0;i<nseqs;i++)
                ckfree(weight[i]);
        ckfree(weight);

}
