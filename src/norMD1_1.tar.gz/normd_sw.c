/* NORMD version 1.1 feb 2002 */
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <math.h>
#include "score.h"

extern int readmatrix(FILE *ifd);
extern float show_pair(int i,int j);
extern float pcidentity(int i,int j);
extern int readmsf(FILE *fd);
extern int countmsf(FILE *fd);
extern float md_score(float matrix[NUMRES][NUMRES],float **weight,float totweight,Boolean *fragment);
extern float max_score(int len,Boolean *fragment);
extern void score_gaps(int s1,int s2);

void calc_md(void);
void copy_msf_tmsf(void);
void cut_block(int is,int ie);
void score_block(int block);

int *use_seq;
char **names;
char **seq_array;
int *seqlen_array;
int seqlength;
int nseqs;
int *useqlen_array;
int useqlength;
Boolean *fragment;

char **tseq_array;
int *tseqlen_array;
int tseqlength;

float matrix[NUMRES][NUMRES];
float go;
float ge;

double **tmat;
float **seqweight;
float **gop;
float **gep;

float norm_md,col;
float max_colscore;
int maxlen;
int query;

int blocklen;

int **groups;
int ngroups;
int norphans;

float **pcid;

int main(int argc, char **argv)
{
	FILE *ofd,*ifd,*tfd;
	int  i,j,l,n,ires;
	int err,ix;
	Boolean eof,found;
	int nblocks,block,is,ie;

	if(argc!=6) {
		fprintf(stderr,"%s Version 1.1\n",argv[0]);
		fprintf(stderr,"Usage: %s aln_file matrix gop gep window_length\n",argv[0]);
		return 0;
	}
/* open the test aln file */

        if((tfd=fopen(argv[1],"r"))==NULL) {
            fprintf(stderr,"Cannot open test aln file [%s]\n",argv[1]);
            return 0;
        }


/* open the matrix file */

        if((ifd=fopen(argv[2],"r"))==NULL) {
            fprintf(stderr,"Cannot open matrix file [%s]",argv[2]);
            return 0;
        }

	go=atof(argv[3]);
	ge=atof(argv[4]);

	blocklen=atoi(argv[5]);

/* read the test aln into names, seq_array, seqlength */
        nseqs = countmsf(tfd);
        if(nseqs==0) {
                /*fprintf(stderr,"Error: no sequences in %s\n",argv[1]);*/
                return 0; 
        }
        names=(char **)ckalloc((nseqs+1)*sizeof(char *));
        seq_array=(char **)ckalloc((nseqs+1)*sizeof(char *));
        seqlen_array=(int *)ckalloc((nseqs+1)*sizeof(int));
        for(i=0;i<nseqs;i++) {
                names[i]=(char *)ckalloc((MAXNAMES+1)*sizeof(char));
        }
        err=readmsf(tfd);
	if(err>0) {
                fprintf(stdout,"Warning: alignment too long\n");
		return 0;
	}

	for(i=0;i<nseqs;i++)
		for(j=0;j<seqlen_array[i];j++)
			if(isalpha(seq_array[i][j]))
				seq_array[i][j]=toupper(seq_array[i][j]);

	err=readmatrix(ifd);
	if(err<=0) {
		fprintf(stderr,"Error: bad matrix in %s\n",argv[3]);
		exit;
	}
        tseq_array=(char **)ckalloc((nseqs+1)*sizeof(char *));
        tseqlen_array=(int *)ckalloc((nseqs+1)*sizeof(int));
        for(i=0;i<nseqs;i++) {
                tseq_array[i]=(char *)ckalloc((seqlength+1)*sizeof(char));
        }

	copy_msf_tmsf();

	if(blocklen-blocklen/2==1) 
		nblocks=seqlength/blocklen;
	else 
		nblocks=seqlength/blocklen+1;
		
	norm_md=0.0;
	for (block=0;block<blocklen/2;block++) 
        	fprintf(stdout,"%d %.3f \n",block+1,norm_md);

	for (block=blocklen/2;block<tseqlength-blocklen/2;block++) {
		is=block-blocklen/2;
		ie=is+blocklen;
		if(ie>tseqlength) is=tseqlength;

		cut_block(is,ie);
		score_block(block);

	}

	norm_md=0.0;
	for (block=tseqlength-blocklen/2;block<tseqlength;block++) 
        	fprintf(stdout,"%d %.3f \n",block+1,norm_md);
}

void score_block(int block)
{
	int i,j,l,n;
	Boolean found;

/* remove the gaps */
        useqlen_array=(int *)ckalloc((nseqs+1)*sizeof(int));
	useqlength=0;
	for(i=0;i<nseqs;i++) {
		l=0;
		for(j=0;j<seqlen_array[i];j++)
			if(isalpha(seq_array[i][j])) {
				l++;
			}
		useqlen_array[i]=l;
		if (l>useqlength) useqlength=l;
	}

	
/* calculate some simple statistics */
	maxlen=0;
        tmat=(double **)ckalloc((nseqs+2)*sizeof(double *));
        for(i=0;i<=nseqs;i++)
                tmat[i]=(double *)ckalloc((nseqs+2)*sizeof(double));
	pcid=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                pcid[i]=(float *)ckalloc((nseqs+1)*sizeof(float));
        for(i=0;i<nseqs;i++) {
                l=useqlen_array[i];
                if(l>maxlen) maxlen=l;
		tmat[i+1][i+1]=0.0;
		for(j=i+1;j<nseqs;j++) {
			pcid[j][i]=pcid[i][j]=pcidentity(i,j);
			tmat[i+1][j+1]=1.0-pcid[i][j];
			tmat[j+1][i+1]=tmat[i+1][j+1];
		}
	}

	use_seq=(int *)ckalloc((nseqs+1)*sizeof(int));
	for(i=0;i<nseqs;i++)
		use_seq[i]=2;

        groups=(int **)ckalloc((nseqs+1)*sizeof(int *));
        for(i=0;i<nseqs;i++)
                groups[i]=(int *)ckalloc((nseqs+1)*sizeof(int));
        calc_groups(query,0.5);

        for(i=0;i<ngroups;i++) {
                found=FALSE;
                for(j=0;j<nseqs;j++) {
                        if(use_seq[j]>1 && groups[i][j]==1) {
                                if(!found) {
                                        found=TRUE;
                                }
                                else use_seq[j]=(-1);
                        }
                }
        }

        seqweight=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                seqweight[i]=(float *)ckalloc((nseqs+1)*sizeof(float));

        for(i=0;i<nseqs;i++) 
		for(j=i;j<nseqs;j++) {
			seqweight[j][i]=seqweight[i][j]=tmat[i+1][j+1];
		}

/* calculate the scores for the gaps */
        gop=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                gop[i]=(float *)ckalloc((nseqs+1)*sizeof(float));
        gep=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                gep[i]=(float *)ckalloc((nseqs+1)*sizeof(float));

       	for(i=0,n=0;i<nseqs;i++) 
              	for(j=i+1;j<nseqs;j++)
			score_gaps(i,j);


	fragment=(Boolean *)ckalloc((nseqs+1)*sizeof(Boolean));
	calc_md();

        fprintf(stdout,"%d %.3f \n",block+1,norm_md);

        for(i=0;i<ngroups;i++)
                ckfree(groups[i]);
        ckfree(groups);
        for(i=0;i<nseqs;i++)
                ckfree(gop[i]);
        ckfree(gop);
        for(i=0;i<nseqs;i++)
                ckfree(gep[i]);
        ckfree(gep);

        for(i=0;i<=nseqs;i++)
                ckfree(tmat[i]);
        ckfree(tmat);
        for(i=0;i<nseqs;i++)
                ckfree(pcid[i]);
        ckfree(pcid);

	ckfree(use_seq);
	ckfree(fragment);
        for(i=0;i<nseqs;i++)
                ckfree(seqweight[i]);
        ckfree(seqweight);

	ckfree(useqlen_array);

}

void copy_msf_tmsf(void) 
{
	int i,j;

	for(i=0;i<nseqs;i++) {
		for(j=0;j<seqlength;j++) 
			tseq_array[i][j]=seq_array[i][j];
		tseqlen_array[i]=seqlen_array[i];
	}
	tseqlength=seqlength;
}

void cut_block(int is, int ie)
{
	int i,j,len;

	len=ie-is;
	for(i=0;i<nseqs;i++) {
		for(j=is;j<ie;j++) 
			seq_array[i][j-is]=tseq_array[i][j];
		seqlen_array[i]=len;
	}
	seqlength=len;


}

void calc_md(void)
{
	int i,j,n,n1,ntot;
	float id,meanid;
	float totweight;
	float gap_openscore,gap_extscore;
	float ll;
	float medianqpw;
	float tl,q1,q3;
	float tmp;
	float **weight;
	float *qpw;

	ntot=0;
        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>0) ntot++;
	if(ntot==1) {
		norm_md=1.0;
		return;
	}

        weight=(float **)ckalloc((nseqs+1)*sizeof(float *));
        for(i=0;i<nseqs;i++)
                weight[i]=(float *)ckalloc((nseqs+1)*sizeof(float));

	totweight=0;
        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>0) 
		for(j=i+1;j<nseqs;j++) 
			if(use_seq[j]>0) 
				totweight+=seqweight[i][j];

	if (totweight==0) {
        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>0)
		for(j=i+1;j<nseqs;j++) 
			if(use_seq[j]>0)
				totweight++;
	}

        for(i=0;i<nseqs;i++) 
		if(use_seq[i]>0)
		for(j=i+1;j<nseqs;j++) 
			if(use_seq[j]>0) {
			weight[j][i]=weight[i][j]=seqweight[i][j];
			}

/* calculate pairwise alignment scores using k-tuple scores */
	qpw=(float *)ckalloc((nseqs*nseqs+1)*sizeof(float));
        for(i=0,n=0;i<nseqs;i++)
		if(use_seq[i]>0)
                for(j=i+1;j<nseqs;j++) 
			if(use_seq[j]>0) {
                        qpw[n]=show_pair(i,j);
                        n++;
                }


	gap_openscore=0.0;
	gap_extscore=0.0;
       	for(i=0,n=0;i<nseqs;i++) 
		if(use_seq[i]>0) {
              		for(j=i+1;j<nseqs;j++) {
				if(use_seq[j]>0) {
				gap_openscore+=gop[i][j]*weight[i][j];
				gap_extscore+=gep[i][j]*weight[i][j];
				n++;
				}
			}
		}
	gap_openscore/=(float)totweight;
        gap_extscore/=(float)totweight;


/* sort the pairwise k-tuple scores into ascending order */
        sort_scores(qpw,0,n-1);

/* find the lower quartile range of the pairwise k-tuple scores */
        if(n == 0)
                medianqpw = 0;
        else if(n % 2 == 0)
                medianqpw=(qpw[n/2-1]+qpw[n/2])/2.0;
        else
                medianqpw=qpw[n/2];

        if(n==0)
                ll=0;
        else {
                tl = (float)n/4.0 + 0.5;
                if(tl - (int)tl == 0.5) {
                        q3=(qpw[(int)tl]+qpw[(int)tl+1])/2.0;
                        q1=(qpw[n-(int)tl]+qpw[n-(int)tl-1])/2.0;
                }
                else if(tl - (int)tl > 0.5) {
                        q3=qpw[(int)tl+1];
                        q1=qpw[n-(int)tl-1];
                }
                else {
                        q3=qpw[(int)tl];
                        q1=qpw[n-(int)tl];
                }
/* use lower quartile range if more than 10 sequences, otherwise use mean */
        }
	if(q1<10) q1=10;
	q1=1.14*q1-6.4;

/* calculate mean column score */
	max_colscore=max_score(maxlen,fragment);
	col=md_score(matrix,weight,totweight,fragment);
	if(blocklen==1) norm_md=col;
	else {
        	if(max_colscore>0.0) {
			norm_md=100.0*(col-gap_openscore*go-gap_extscore*ge)/(max_colscore*q1);
		}
        	else norm_md=0.0;
		if (norm_md<0) norm_md=0;
	}

        for(i=0;i<nseqs;i++)
                ckfree(weight[i]);
        ckfree(weight);
        ckfree(qpw);


}
