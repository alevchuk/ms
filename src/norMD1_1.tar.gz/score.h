#define MAXNAMES 50
#define MAXLINE 2048

#define Boolean short
#define TRUE 1
#define FALSE 0
#define EOS '\0'

#define INT_SCALE_FACTOR 100 /* Scaling factor to convert float to integer for profile scores */
#define NUMRES 32		/* max size of comparison matrix */

#define LEFT 1
#define RIGHT 2

#define NODE 0
#define LEAF 1


typedef struct node {		/* phylogenetic tree structure */
        struct node *left;
        struct node *right;
        struct node *parent;
        float dist;
        int  leaf;
        int order;
        char name[64];
} stree, *treeptr;

void *ckalloc(size_t bytes);

/* trees.c */
void guide_tree(FILE *tree,int nseqs);

int SeqGCGCheckSum(char *seq, int len);

/* xscore.c */
void make_colscores(void);

float show_pair(int i,int j);
